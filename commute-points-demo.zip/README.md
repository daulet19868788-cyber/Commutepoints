# Commute Points Demo

Локальный демо-проект — показывает:
- Individuals leaderboard (пользователи)
- Teams leaderboard (сумма очков команды)
- Кнопка "+ Add Commute" для текущего пользователя
- Mock Strava: автоматическая генерация поездок каждые 20 секунд

Как запустить локально:
1. Распакуй архив.
2. В папке проекта запусти:
   npm install
   npm start
3. Откроется http://localhost:3000

Как задеплоить на GitHub Pages:
1. Сбилдь приложение: npm run build
2. Содержимое папки build залей в /docs ветки main (или используй gh-pages).

Файлы:
- public/index.html
- src/* (React app)
- package.json (скрипты start/build)

Примечание: проект использует localStorage для хранения очков (демо).
